//#include <stdio.h>
//
//main ()
//{
//	int n[5]={1,2,3,4,5};
//	printf("%d", n[0]);
//}


//loop with array

//#include <stdio.h>

//main ()
//{
//	int n[5]={1,2,3,4,5};
//	
//	int i;
//	for(i=0;i<5;i++)
//	{
//		printf("\n%d",n[i]);
//	}
//	}


//



//#include <stdio.h>
//
//main ()
//{
//	int n[5]={9,4,5,2,7};
//	
//	int i,sum=0;
//
//	for(i=0;i<5;i++)
//	{
//		printf("\n%d",n[i]);
//		sum=sum+n[i];
//	}
//	printf("\nsum=%d",sum);
//	}

//user defined array

//#include<stdio.h>
//
//main()
//{
//	int n[5]
//	int i;
//	
//	for(i=0;i<5;i++);
//	{
//		printf("enter the element:");
//		scanf("%d",&n[i]);	
//		}
//		
//		for(i=0;i<5;i++)
//		{
//			printf(\n"%d",n[i]);
//		}
//}

